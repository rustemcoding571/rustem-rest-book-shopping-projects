package com.example.rustem.restbookshopping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestBookshoppingApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestBookshoppingApplication.class, args);
	}

}
