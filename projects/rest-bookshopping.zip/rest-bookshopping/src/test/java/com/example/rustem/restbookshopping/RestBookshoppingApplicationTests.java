package com.example.rustem.restbookshopping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestBookshoppingApplicationTests {

	@Test
	void contextLoads() {
	}

}
